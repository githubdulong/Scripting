// 连接状态：逐项体检，定位「连不上」卡在哪一环。
//
// 只做到与设备握手为止，不跑 pair-verify、也不建隧道——那两步慢且有副作用
// （会在设备上开一次性监听）。

import {
  NavigationStack,
  List,
  Section,
  VStack,
  HStack,
  Spacer,
  Text,
  Button,
  Image,
  useState,
  useEffect,
  Navigation,
} from "scripting";
import { collectDiagnostics, probeTunnelTls, type DiagnosticItem } from "../core/session";
import { loadPairing } from "../core/pairing";
import { loadSettings } from "../utils/storage";
import { debugLogText, debugLogCount, clearDebugLog } from "../core/debug";
import { exportDebugLog } from "../utils/logExport";
import { openAppSettings } from "../utils/appSettings";
import { MessageSheet } from "./MessageSheet";

export function DiagnosticsPage() {
  const dismiss = Navigation.useDismiss();
  const [items, setItems] = useState<DiagnosticItem[]>([]);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("");
  // 日志条数会随着后台动作变，进页面时取一次、复制/清空后再刷新就够了。
  const [logCount, setLogCount] = useState(debugLogCount());
  /** TLS 取证的说明浮层——这步有副作用，要先把后果讲清楚。 */
  const [showProbeIntro, setShowProbeIntro] = useState(false);

  async function run() {
    setBusy(true);
    setItems([]);
    try {
      const settings = loadSettings();
      const result = await collectDiagnostics({
        endpoint: { host: settings.deviceHost, source: settings.tunnelSource },
        record: loadPairing(),
        onStatus: setStatus,
      });
      setItems(result);
      setStatus("");
      setLogCount(debugLogCount());
    } catch (error) {
      setStatus(`诊断失败：${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setBusy(false);
    }
  }

  /**
   * TLS-PSK 取证。
   *
   * 会消费掉一次性的隧道监听，跑完要重新配对握手才能开模拟——所以做成按钮，
   * 而且先问一句。只有排查「隧道建不起来」时才需要它。
   */
  /** 点按钮只负责弹说明；真的跑要等用户在浮层里确认。 */
  function runTlsProbe() {
    if (!loadPairing()) {
      setStatus("没有配对记录，无法探测");
      return;
    }
    setShowProbeIntro(true);
  }

  async function confirmTlsProbe() {
    setShowProbeIntro(false);
    const record = loadPairing();
    if (!record) return;

    setBusy(true);
    try {
      const settings = loadSettings();
      const detail = await probeTunnelTls(
        record,
        { host: settings.deviceHost, source: settings.tunnelSource },
        setStatus,
      );
      setStatus(`TLS 探测：${detail}`);
    } catch (error) {
      setStatus(`探测失败：${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setBusy(false);
    }
  }

  /** 导出实现见 `utils/logExport`——设置主页那个直达入口走的是同一条路。 */
  async function exportLog() {
    setBusy(true);
    try {
      setStatus(await exportDebugLog());
    } catch (error) {
      setStatus(`导出失败：${error instanceof Error ? error.message : String(error)}`);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    void run();
  }, []);

  const failed = items.filter((item) => item.ok === false);
  /*
    链路到底通没通，只认带 `critical` 标记的那几项（目前就是「设备握手」）。

    别拿 `failed.length === 0` 当通的标准：读 VPN 状态时撞上并发变更会留一个
    红叉，而握手照样是成的。
  */
  const linkOk = items.some((item) => item.critical && item.ok === true);

  return (
    <NavigationStack>
      <List
        navigationTitle="连接状态"
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          cancellationAction: <Button title="关闭" action={() => dismiss()} />,
          confirmationAction: <Button title={busy ? "检测中…" : "重新检测"} disabled={busy} action={() => void run()} />,
        }}
        sheet={{
          content: (
            <MessageSheet
              tone="info"
              message={
                "跑一次 TLS 取证？\n" +
                "会向设备申请一个一次性的隧道监听并把它用掉。\n\n" +
                "跑完这次，本次会话要重新配对握手才能开始模拟。\n\n" +
                "只有在「建立加密隧道失败」时才需要它。"
              }
              confirm={{ label: "开始探测", onConfirm: () => void confirmTlsProbe() }}
              onDismiss={() => setShowProbeIntro(false)}
            />
          ),
          isPresented: showProbeIntro,
          onChanged: setShowProbeIntro,
        }}
      >
        {!!status && (
          <Section>
            <HStack spacing={8}>
              <Image systemName="hourglass" foregroundStyle="secondaryLabel" />
              <Text font="caption" foregroundStyle="secondaryLabel">{status}</Text>
            </HStack>
          </Section>
        )}

        {items.length > 0 && (
          <Section
            header={<Text font="caption" foregroundStyle="secondaryLabel">检测结果</Text>}
            footer={
              failed.length === 0 ? (
                <Text font="caption2" foregroundStyle="tertiaryLabel">
                  各项正常。若仍连不上，多半卡在隧道握手那一步，详见 scripting-cli 终端里的日志。
                </Text>
              ) : linkOk ? (
                /*
                  有红叉，但握手是成的。

                  这两件事同时为真是常态：读 VPN 状态时撞上「配置正在变化」就会
                  留一个红叉，而那条隧道在代理模式下本来也不归我们管。以前这里
                  一律说「第一个红叉就是断点所在」，于是用户拿着一条已经走通的
                  链路去查一个无关的红叉。握手通了就直说通了。
                */
                <Text font="caption2" foregroundStyle="systemGreen">
                  设备握手已成功，链路是通的。上面 {failed.length} 项异常不影响连接，
                  多半是读状态时撞上了系统正在切换 VPN。
                </Text>
              ) : (
                <Text font="caption2" foregroundStyle="systemOrange">
                  有 {failed.length} 项异常，从上往下第一个红叉就是断点所在。
                </Text>
              )
            }
          >
            {items.map((item, index) => (
              <HStack key={`${item.label}-${index}`} frame={{ maxWidth: "infinity" }} spacing={10}>
                <Image
                  systemName={
                    item.ok === null
                      ? "info.circle"
                      : item.ok
                        ? "checkmark.circle.fill"
                        : "xmark.circle.fill"
                  }
                  foregroundStyle={item.ok === null ? "secondaryLabel" : item.ok ? "systemGreen" : "systemRed"}
                  frame={{ width: 22 }}
                />
                <VStack alignment="leading" spacing={2}>
                  <Text font="subheadline" foregroundStyle="label">{item.label}</Text>
                  <Text font="caption2" foregroundStyle="secondaryLabel">{item.value}</Text>
                </VStack>
                <Spacer />
              </HStack>
            ))}
          </Section>
        )}

        {/*
          一键跳到 Scripting 在「设置」里的那一页。

          实时活动、本地网络、通知三个开关都在那儿，而它们被关掉正是
          「卡片不显示」「找不到设备」最常见的原因。系统设置的深链跳不过去
          （实测全被重定向到 App 列表），这一跳是 iOS 唯一开放的。
        */}
        <Section
          header={<Text font="caption" foregroundStyle="secondaryLabel">权限与开关</Text>}
          footer={
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              实时活动、本地网络、通知都在那一页。
              开发者模式不在这儿——它在「设置 → 隐私与安全性 → 开发者模式」，
              系统不允许应用直接跳过去。
            </Text>
          }
        >
          <Button
            title="打开 Scripting 的设置页"
            systemImage="gear"
            action={() => void openAppSettings()}
          />
        </Section>

        <Section
          header={<Text font="caption" foregroundStyle="secondaryLabel">进阶取证</Text>}
          footer={
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              只在「建立加密隧道失败」时才需要。向设备要一个隧道监听并自己发一个
              TLS 1.2 ClientHello：回 ServerHello 说明设备侧是好的，问题在客户端；
              回 Alert 则带着设备的拒绝原因。
              {"\n\n"}
              会用掉那个一次性监听，跑完要重新配对握手才能开始模拟。
            </Text>
          }
        >
          <Button
            title={busy ? "进行中…" : "跑一次 TLS 取证"}
            systemImage="stethoscope.circle"
            disabled={busy}
            action={runTlsProbe}
          />
        </Section>


        {/*
          运行日志。
          反馈问题时最有用的东西。不连电脑也能拿到——缓冲区常开。
          默认给「导出为文件」：几百条日志贴进聊天窗口谁也读不下去，
          存成 txt 丢过去，对面想看哪段看哪段。
        */}
        <Section
          header={<Text font="caption" foregroundStyle="secondaryLabel">运行日志</Text>}
          footer={
            <Text font="caption2" foregroundStyle="tertiaryLabel">
              记录最近 600 条，满了自动丢最老的；脚本一关全没，不落盘。
              导出和复制都会自动脱敏：坐标只保留 1 位小数、地名和自定义文本打码、
              地址和设备标识只留前缀。密钥材料本来就只记长度。
            </Text>
          }
        >
          <Button
            title={logCount > 0 ? `导出为文件（${logCount} 条）` : "暂无日志"}
            systemImage="square.and.arrow.up"
            disabled={logCount === 0 || busy}
            action={() => void exportLog()}
          />
          <Button
            title="复制到剪贴板"
            systemImage="doc.on.doc"
            disabled={logCount === 0}
            action={() => {
              Pasteboard.setString(debugLogText());
              setStatus(`已复制 ${logCount} 条日志`);
            }}
          />
          <Button
            title="清空日志"
            systemImage="trash"
            role="destructive"
            disabled={logCount === 0}
            action={() => {
              clearDebugLog();
              setLogCount(0);
              setStatus("日志已清空");
            }}
          />
          <Button
            title="刷新条数"
            systemImage="arrow.clockwise"
            action={() => setLogCount(debugLogCount())}
          />
        </Section>

        <Section
          header={<Text font="caption" foregroundStyle="secondaryLabel">连不上时先看这几条</Text>}
        >
          <VStack alignment="leading" spacing={8}>
            <Text font="caption">① 用蜂窝数据时：确认隧道已连接 → 控制中心开关一次飞行模式 → 重新开始模拟。连上之后蜂窝照常用，本地网络只在起步那一刻需要</Text>
            <Text font="caption">② 开发者模式要开着（设置 → 隐私与安全性 → 开发者模式）</Text>
            <Text font="caption">③ 更新系统后设备侧的配对授权会失效，去「配对」页重新配一次（不必重装脚本）</Text>
            <Text font="caption">④ iOS 同时只允许一条 VPN 生效，代理和 Scripting 自身的隧道会互相顶掉</Text>
            <Text font="caption">⑤ 选「代理工具提供」时，代理那边要把 tun 的 loopback-address 配成对端地址</Text>
            <Text font="caption">⑥ 代理模式下代理工具要自己确认是否在运行——iOS 不让应用读别家的 VPN，这里看不出来</Text>
          </VStack>
        </Section>
      </List>
    </NavigationStack>
  );
}
